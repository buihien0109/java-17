package com.example.demojparelationship;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DemoJpaRelationshipApplication {

    public static void main(String[] args) {
        SpringApplication.run(DemoJpaRelationshipApplication.class, args);
    }

}
